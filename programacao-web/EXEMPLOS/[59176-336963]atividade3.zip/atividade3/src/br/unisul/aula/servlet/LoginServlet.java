package br.unisul.aula.servlet;

import br.unisul.aula.base.DB;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Base64;

@WebServlet(name = "LoginServlet", urlPatterns = "/logar")
public class LoginServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        out.println("<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
                "    <title>Login</title>\n" +
                "</head>\n" +
                "<body>\n");
        if (request.getAttribute("logado")!=null) {
            if (request.getAttribute("logado").equals("n")) {
                out.println("<h1>Login inválido</h1>");
            }
        }
        out.println("<h1>Login</h1>\n" +
                "<form action=\"/logar\" method=\"post\">\n" +
                "    Login: <input type=\"text\" name=\"txtLogin\"><br/>\n" +
                "    Senha: <input type=\"password\" name=\"pasSenha\"> <br/> <br/>\n" +
                "    <input type=\"submit\" value=\"Logar\"> &nbsp; <input type=\"reset\" value=\"Limpar\">\n" +
                "    <br/>\n" +
                "    <br/>\n" +
                "    <a href=\"criarUsuario\">Criar Usuário</a>\n" +
                "</form>\n" +
                "</body>\n" +
                "</html>");
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String login = request.getParameter("txtLogin");
        String senha = request.getParameter("pasSenha");
        DB base = DB.getInstance();
        base.iniciar();
        if (base.validarUsuarioSenha(login,senha)) {
            byte[] bytes = login.getBytes("UTF-8");
            String encoded = Base64.getEncoder().
                    encodeToString(bytes);
            // IMPORTANTE
            session.setAttribute("login", encoded);
            response.sendRedirect("/cadAluno");
            //**************
        } else {
            request.setAttribute("logado", "n");
            doGet(request,response);
        }

    }
}
