package br.unisul.aula.signo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "SignoServlet", urlPatterns = "/signos")
public class SignoServlet extends HttpServlet {
    private String msg="";
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {
        String data = request.getParameter("dtNascimento");
        Signo signo = Signo.definirSigno(data);
        msg="<h1>Signo:"+signo.getSigno()+"<h1>";
        doGet(request,response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        out.println("<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
                "    <title>Signo</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<h1>Pesquisa</h1>\n" +
                "<form action=\"/signos\" method=\"post\">\n" +
                "    Data de Nascimento: <input type=\"date\" name=\"dtNascimento\"><br/>\n" +
                "    <input type=\"submit\" value=\"Verificar Signo\"> &nbsp; <input type=\"reset\" value=\"Limpar\">\n" +
                "    <br/>\n" +
                "    <br/>\n" +
                msg+
                "</form>\n" +
                "</body>\n" +
                "</html>");
        msg="";
    }
}
