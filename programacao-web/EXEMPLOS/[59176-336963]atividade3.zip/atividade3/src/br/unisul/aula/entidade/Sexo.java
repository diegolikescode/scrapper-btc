package br.unisul.aula.entidade;

public enum Sexo {
    MASC("M","Masculino"), FEM("F","Feminino");

    private String sigla, descricao;

    Sexo(String sigla, String descricao) {
        this.sigla=sigla;
        this.descricao=descricao;
    }

    public String getSigla() {
        return sigla;
    }

    public String getDescricao() {
        return descricao;
    }
}
