package br.unisul.aula.pesquisa;

public class Resposta {
    private Pergunta pergunta;
    private String resposta;


    public Resposta(Pergunta pergunta, String resposta) {
        this.pergunta = pergunta;
        this.resposta = resposta;
    }

    public Pergunta getPergunta() {
        return pergunta;
    }

    public String getResposta() {
        return resposta;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Resposta)) return false;

        Resposta resposta1 = (Resposta) o;

        if (getPergunta() != null ? !getPergunta().equals(resposta1.getPergunta()) : resposta1.getPergunta() != null)
            return false;
        return getResposta() != null ? getResposta().equals(resposta1.getResposta()) : resposta1.getResposta() == null;
    }

    @Override
    public int hashCode() {
        int result = getPergunta() != null ? getPergunta().hashCode() : 0;
        result = 31 * result + (getResposta() != null ? getResposta().hashCode() : 0);
        return result;
    }
}
