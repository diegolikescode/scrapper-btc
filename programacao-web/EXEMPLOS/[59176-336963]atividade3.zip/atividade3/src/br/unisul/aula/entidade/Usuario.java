package br.unisul.aula.entidade;

public class Usuario {
    private String login;
    private String senha;
    private Pessoa pessoa;

    public Usuario(String login, String senha, String nome) {
        this.login = login;
        this.senha = senha;
        this.pessoa = new Pessoa(nome);
    }

    public String getLogin() {
        return login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public boolean verificarLogin(String login, String senha){
        if ((this.login.equals(login)) && (this.senha.equals(senha))){
            return true;
        } else {
            return false;
        }
    }
}
