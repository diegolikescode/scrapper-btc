package br.unisul.aula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjectParticipantesApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringProjectParticipantesApplication.class, args);
    }

}
