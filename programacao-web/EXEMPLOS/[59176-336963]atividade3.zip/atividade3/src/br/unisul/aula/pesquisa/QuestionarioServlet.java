package br.unisul.aula.pesquisa;

import br.unisul.aula.base.DB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "QuestionarioServlet", urlPatterns = "/quiz")
public class QuestionarioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        DB base = DB.getInstance();
        if (base.listarPergunta().size()==0){
            base.iniciar();
        }
        int inicio=0;
        if (session.getAttribute("pag")==null){
            session.setAttribute("pag","1");
        } else {
            String novaPesquisa = request.getParameter("nova")==null?"sim":request.getParameter("nova");
            if (novaPesquisa.equalsIgnoreCase("sim")){
                session.setAttribute("pag","1");
            }
            if (session.getAttribute("pag").equals("2")){
                inicio=5;
            }
        }
        PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");

        out.println("<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
                "    <title>Questionário "+session.getAttribute("pag")+"</title>\n" +
                "</head>\n" +
                "<body>\n");
        if (!session.getAttribute("pag").equals("3")) {
            out.println("<h1>Questionário " + session.getAttribute("pag") + "</h1>\n" +
                    "<form action=\"/quiz?nova=nao\" method=\"post\">\n");

            for (int i = 0; i < 5; i++) {

                out.println("    <b>" + base.listarPergunta().get(inicio).getPergunta() + "</b>\n" +
                        "  <label><input type=\"radio\" name=\"" +
                        base.listarPergunta().get(inicio).
                        getSgPergunta() + "\" value=\"S\">Sim </label>&nbsp;&nbsp;\n" +
                        "    <label><input type=\"radio\" name=\"" + base.listarPergunta().get(inicio).getSgPergunta() + "\" value=\"N\">Não</label>\n" +
                        "\n<br>");
                inicio++;
            }
            out.println("    <input type=\"submit\" value=\"Próximo\">\n");
            out.println("</form>\n" +
                    "\n");
        }else{
        out.println("<h1>Resumo</h1>\n" +
                "\n" +
                "<table>\n" +
                "    <tr>\n" +
                "        <th>Pergunta</th>\n" +
                "        <th>Quantidade de respostas SIM</th>\n" +
                "        <th>Quantidade de respostas NÃO</th>\n" +
                "    </tr>\n");
            for (Pergunta pergunta: base.listarPergunta()) {

                out.println("    <tr>\n" +
                        "        <td>"+pergunta.getPergunta()+"</td>\n");
                out.println("        <td>");
                int contadorSim=0;
                int contadorNao=0;
                for (Resposta resp: base.listarResposta()) {
                    if (resp.equals(new Resposta(pergunta, "S"))){
                        contadorSim++;
                    } else {
                        if (resp.equals(new Resposta(pergunta, "N"))){
                            contadorNao++;
                        }
                    }
                }
                out.println(contadorSim);
                out.println("        </td>");
                out.println("        <td>");
                out.println(contadorNao);

                out.println("</td>\n" +
                            "    </tr>\n");
            }
            out.println("</table>\n" +
                "\n" );
            out.println("    <a href=\"/quiz?nova=sim\">Nova pequisa\n");
        }
        out.println("</body>\n" +
                "</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        DB base = DB.getInstance();
        int inicio=0;
        if (session.getAttribute("pag")==null){
            session.setAttribute("pag","1");
        } else {
            if (session.getAttribute("pag").equals("1")){
                session.setAttribute("pag","2");
            } else {
                if (session.getAttribute("pag").equals("2")){
                    session.setAttribute("pag","3");
                }
            }
        }

        for (Pergunta pergunta: base.listarPergunta()){
            String resp = request.getParameter(pergunta.getSgPergunta())==null?"n/a":request.getParameter(pergunta.getSgPergunta());
            if (!resp.equalsIgnoreCase("n/a")) {
                Resposta resposta = new Resposta(pergunta, resp);
                base.incluirResposta(pergunta, resp.toUpperCase());
            }
        }
        doGet(request, response);
    }
}
