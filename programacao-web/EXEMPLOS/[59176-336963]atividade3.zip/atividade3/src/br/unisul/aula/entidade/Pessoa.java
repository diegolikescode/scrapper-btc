package br.unisul.aula.entidade;

public class Pessoa {
    private String nome;
    private Pessoa mae;
    private int idade;
    private Sexo sexo;

    public Pessoa(String nome) {
        this.nome = nome;
    }
    public Pessoa(String nome, int idade, Sexo sexo) {
        this.nome = nome;
        this.idade=idade;
        this.sexo=sexo;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Pessoa getMae() {
        return mae;
    }

    public void setMae(Pessoa mae) {
        this.mae = mae;
    }

    public int getIdade() {
        return idade;
    }

    public Sexo getSexo() {
        return sexo;
    }
}
