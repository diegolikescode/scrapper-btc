USE `mydb`;

INSERT en_endereco 
	(logradouro, numero) 
    values ('rua x', 10);
select * from en_endereco;
-- DELETE FROM en_endereco WHERE seq_endereco > 1;

INSERT INTO en_paciente 
	(nome, data_nascimento, sexo, estado_civil, rg, en_endereco_seq_endereco) 
	VALUES ('Amilton', '21/05/1978', 'M', 'S', '3.300.000-00', 1);
INSERT INTO en_paciente (nome, data_nascimento, sexo, estado_civil, rg, en_endereco_seq_endereco) 
	VALUES ('Jose', '02/04/1977', 'F', 'C', '5.100.000-00',1);
INSERT INTO en_paciente (nome, data_nascimento, sexo, estado_civil, rg, en_endereco_seq_endereco) 
	VALUES ('Paulo', '03/03/1988', 'M', 'D', '6.200.000-00',1);
INSERT INTO en_paciente (nome, data_nascimento, sexo, estado_civil, rg, en_endereco_seq_endereco) 
	VALUES ('Ana', '03/03/1988', 'F', 'D', '6.200.000-00',1);
INSERT INTO en_paciente (nome, data_nascimento, sexo, estado_civil, rg, en_endereco_seq_endereco) 
	VALUES ('Marta', '24/07/1978', 'F', 'D', '3.300.000-00',1);
INSERT INTO en_paciente (nome, data_nascimento, sexo, estado_civil, rg, en_endereco_seq_endereco) 
	VALUES ('Alice', '25/08/1978', 'F', 'C', '4.300.000-00',1);

SELECT * FROM en_paciente;

UPDATE en_paciente SET nome='Carlos', data_nascimento='20/09/1999'
	WHERE seq_paciente=2;

UPDATE en_paciente SET estado_civil='D'
	WHERE seq_paciente=2;
    
INSERT INTO en_medico (nome) VALUES ('Dr Paulo');
INSERT INTO en_medico (nome) VALUES ('Dra Ana Paula');
INSERT INTO en_medico (nome) VALUES ('Dr Eduardo');
INSERT INTO en_medico (nome) VALUES ('Dra Ivone');
select * from en_medico;
DELETE FROM en_medico WHERE seq_medico > 4;

-- seq_convenio nao foi autoincremental
INSERT INTO en_convenio (seq_convenio, nomeempresa) VALUES (1, 'Santa Paulina');
INSERT INTO en_convenio (seq_convenio, nomeempresa) VALUES (2, 'Santo Agostinho');
select * from en_convenio;

INSERT INTO re_paciente_convenio (en_paciente_seq_paciente, en_convenio_seq_convenio)  VALUES (1, 1);
INSERT INTO re_paciente_convenio (en_paciente_seq_paciente, en_convenio_seq_convenio)  VALUES (1, 2);
INSERT INTO re_paciente_convenio (en_paciente_seq_paciente, en_convenio_seq_convenio)  VALUES (2, 1);
INSERT INTO re_paciente_convenio (en_paciente_seq_paciente, en_convenio_seq_convenio)  VALUES (3, 2);
select * from re_paciente_convenio;