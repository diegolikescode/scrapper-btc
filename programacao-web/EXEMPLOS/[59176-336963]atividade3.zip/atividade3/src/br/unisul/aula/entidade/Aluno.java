package br.unisul.aula.entidade;

import java.util.ArrayList;
import java.util.List;

public class Aluno extends Pessoa {

    private List<Disciplina> disciplinas;

    public Aluno(String nome) {
        super(nome);
        disciplinas=new ArrayList<>();
    }

    public Aluno(String nome, int idade, Sexo sexo, List<Disciplina> disc) {
        super(nome, idade, sexo);
        this.disciplinas = disc;
    }

    public void setDisciplinas(Disciplina disciplina){
        this.disciplinas.add(disciplina);
    }

    public String listarDisciplina(){
        String msg="";
        for (Disciplina disciplina: this.disciplinas) {
            msg+=disciplina.getNome()+",";
        }
        return msg;
    }


}
