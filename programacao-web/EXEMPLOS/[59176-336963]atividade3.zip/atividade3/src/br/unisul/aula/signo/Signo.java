package br.unisul.aula.signo;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public enum Signo {
    CAPR("Capricórnio"),
    AQUA("Aquário"),
    PEIX("Peixes");


    private String signo;

     Signo(String signo) {
            this.signo = signo;
    }

    public static Signo definirSigno(
            String dataNascimento){
        String[] data = dataNascimento.split("-");
        int dia = Integer.parseInt(data[2]);
        int mes = Integer.parseInt(data[1]);
        switch(mes) {
            case 1:
                // Enero
                if (dia>=21)
                    return Signo.AQUA;
                else
                    return Signo.CAPR;
            case 2:
                if (dia>=20)
                    return Signo.PEIX;
                else
                    return Signo.AQUA;

        }
        return null;
    }

    public String getSigno() {
        return signo;
    }

}
