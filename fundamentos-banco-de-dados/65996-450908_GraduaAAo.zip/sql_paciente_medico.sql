SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`en_endereco`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`en_endereco` (
  `seq_endereco` INT NOT NULL AUTO_INCREMENT,
  `logradouro` VARCHAR(45) NULL,
  `numero` INT NULL,
  `cidade` VARCHAR(45) NULL,
  PRIMARY KEY (`seq_endereco`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`en_paciente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`en_paciente` (
  `seq_paciente` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) NOT NULL,
  `data_nascimento` VARCHAR(10) NULL,
  `sexo` VARCHAR(1) NULL,
  `estado_civil` VARCHAR(45) NULL,
  `rg` VARCHAR(45) NULL,
  `en_endereco_seq_endereco` INT NOT NULL,
  PRIMARY KEY (`seq_paciente`),
  INDEX `fk_en_paciente_en_endereco1_idx` (`en_endereco_seq_endereco` ASC),
  CONSTRAINT `fk_en_paciente_en_endereco1`
    FOREIGN KEY (`en_endereco_seq_endereco`)
    REFERENCES `mydb`.`en_endereco` (`seq_endereco`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`en_medico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`en_medico` (
  `seq_medico` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) NULL,
  `especialidade` VARCHAR(255) NULL,
  `CRM` VARCHAR(45) NULL,
  PRIMARY KEY (`seq_medico`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`en_consultamedica`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`en_consultamedica` (
  `seq_consultamedica` INT NOT NULL AUTO_INCREMENT,
  `data` VARCHAR(10) NULL,
  `diagnostico` VARCHAR(45) NULL,
  `en_paciente_seq_paciente` INT NOT NULL,
  `en_medico_seq_medico` INT NOT NULL,
  PRIMARY KEY (`seq_consultamedica`),
  INDEX `fk_en_consultamedica_en_paciente1_idx` (`en_paciente_seq_paciente` ASC),
  INDEX `fk_en_consultamedica_en_medico1_idx` (`en_medico_seq_medico` ASC),
  CONSTRAINT `fk_en_consultamedica_en_paciente1`
    FOREIGN KEY (`en_paciente_seq_paciente`)
    REFERENCES `mydb`.`en_paciente` (`seq_paciente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_en_consultamedica_en_medico1`
    FOREIGN KEY (`en_medico_seq_medico`)
    REFERENCES `mydb`.`en_medico` (`seq_medico`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`en_exame`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`en_exame` (
  `seq_exame` INT NOT NULL,
  `data` VARCHAR(45) NULL,
  `resultado` TEXT NULL,
  `en_consultamedica_seq_consultamedica` INT NOT NULL,
  PRIMARY KEY (`seq_exame`),
  INDEX `fk_en_exame_en_consultamedica1_idx` (`en_consultamedica_seq_consultamedica` ASC),
  CONSTRAINT `fk_en_exame_en_consultamedica1`
    FOREIGN KEY (`en_consultamedica_seq_consultamedica`)
    REFERENCES `mydb`.`en_consultamedica` (`seq_consultamedica`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`en_convenio`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`en_convenio` (
  `seq_convenio` INT NOT NULL,
  `nomeempresa` VARCHAR(45) NULL,
  `ANS` VARCHAR(45) NULL,
  PRIMARY KEY (`seq_convenio`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`re_paciente_convenio`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`re_paciente_convenio` (
  `seq_re_paciente_convenio` INT NOT NULL AUTO_INCREMENT,
  `en_paciente_seq_paciente` INT NOT NULL,
  `en_convenio_seq_convenio` INT NOT NULL,
  `dta_validade` VARCHAR(45) NULL,
  `tipo_plano` VARCHAR(45) NULL,
  INDEX `fk_re_paciente_convenio_en_paciente_idx` (`en_paciente_seq_paciente` ASC),
  INDEX `fk_re_paciente_convenio_en_convenio1_idx` (`en_convenio_seq_convenio` ASC),
  PRIMARY KEY (`seq_re_paciente_convenio`),
  CONSTRAINT `fk_re_paciente_convenio_en_paciente`
    FOREIGN KEY (`en_paciente_seq_paciente`)
    REFERENCES `mydb`.`en_paciente` (`seq_paciente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_re_paciente_convenio_en_convenio1`
    FOREIGN KEY (`en_convenio_seq_convenio`)
    REFERENCES `mydb`.`en_convenio` (`seq_convenio`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
