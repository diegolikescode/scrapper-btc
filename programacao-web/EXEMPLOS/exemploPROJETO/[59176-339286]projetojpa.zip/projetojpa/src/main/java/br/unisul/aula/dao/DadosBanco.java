package br.unisul.aula.dao;

public interface DadosBanco {
    String USUARIO = "root";
    String SENHA = "1234";
    String SERVIDOR = "localhost";
    String DATABASE = "projeto";
}
