package br.unisul.aula.base;

import br.unisul.aula.entidade.Aluno;
import br.unisul.aula.entidade.Disciplina;
import br.unisul.aula.entidade.Usuario;
import br.unisul.aula.pesquisa.Pergunta;
import br.unisul.aula.pesquisa.Resposta;

import java.util.ArrayList;
import java.util.List;

public class DB {
    private static DB instance = new DB();
    private static List<Usuario> usuarioList = new ArrayList<>();
    private static List<Disciplina> disciplinas = new ArrayList<>();
    private static List<Aluno> alunoList = new ArrayList<>();
    private static List<Pergunta> perguntaList = new ArrayList<>();
    private static List<Resposta> respostaList = new ArrayList<>();
    private DB(){

    }

    public void iniciar(){
        if ((disciplinas.size()<1)) {
            disciplinas.add(new Disciplina("Programação Orientado a Objeto", 1));
            disciplinas.add(new Disciplina("Algoritmos", 2));
            disciplinas.add(new Disciplina("Matemática", 3));
            disciplinas.add(new Disciplina("Português", 4));
            disciplinas.add(new Disciplina("Programação Web", 5));
            disciplinas.add(new Disciplina("Álgebra de Boolean", 6));
            disciplinas.add(new Disciplina("Sistemas Operacionais", 7));
            usuarioList.add(new Usuario("teste", "teste", "teste"));
            for(int i=0;i<10; i++){
                perguntaList.add(new Pergunta("rdnPerg"+(i+1),"Título da perguna nº "+(i+1)));
            }

        }
    }
    public static DB getInstance(){
        return instance;
    }

    public void incluirUsuario(Usuario pessoa){
        usuarioList.add(pessoa);
    }

    public boolean validarUsuarioSenha(String login, String senha){
        for (Usuario usuario: usuarioList) {
            if (usuario.verificarLogin(login, senha)){
                return true;
            }
        }
        return false;
    }
    public List<Usuario> listarTodosUsuarios(){
        return usuarioList;
    }

    public List<Disciplina> listarDisciplinas(){
        return disciplinas;
    }

    public void incluirAluno(Aluno aluno){
        alunoList.add(aluno);
    }
    public List<Aluno> listarAlunos(){
        return alunoList;
    }
    public List<Resposta> listarResposta() {
        return respostaList;
    }

    public List<Pergunta> listarPergunta(){
        return perguntaList;
    }
    public void incluirResposta(Resposta resposta){
        respostaList.add(resposta);
    }
    public void incluirResposta(Pergunta pergunta, String resposta){
        incluirResposta(new Resposta(pergunta,resposta));
    }
}
