package br.unisul.aula.servlet;

import br.unisul.aula.base.DB;
import br.unisul.aula.entidade.Aluno;
import br.unisul.aula.entidade.Disciplina;
import br.unisul.aula.entidade.Sexo;
import br.unisul.aula.entidade.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@WebServlet(name = "AlunoServlet", urlPatterns = "/cadAluno")
public class AlunoServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        DB base = DB.getInstance();
        boolean verificacao = false;
        if (session.getAttribute("login")!=null) {
            byte[] decoded = Base64.getDecoder().decode((String) session.getAttribute("login"));
            String loginValidar = new String(decoded);


            for (Usuario usr : base.listarTodosUsuarios()) {
                if (usr.getLogin().equals(loginValidar)) {
                    verificacao = true;
                    break;
                }
            }
        }
        if (verificacao) {
            PrintWriter out = response.getWriter();
            response.setContentType("text/html;charset=UTF-8");
            out.println("<!DOCTYPE html>\n" +
                    "<html lang=\"en\">\n" +
                    "<head>\n" +
                    "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
                    "    <title>Cadastrar Aluno</title>\n" +
                    "</head>\n" +
                    "<body>\n" +
                    "<h1>Cadastrar Aluno</h1>\n" +
                    "<form action=\"/cadAluno\" method=\"post\">\n" +
                    "    Nome: <input type=\"text\" name=\"txtNome\" required>\n" +
                    "    Idade: <input type=\"number\" name=\"nrIdade\" min=\"0\" max=\"120\" required> <br/>\n" +
                    "    Sexo: <br/><label><input type=\"radio\" name=\"rdSexo\" value=\"M\" required> Masculino</label> &nbsp;&nbsp; <label><input type=\"radio\" name=\"rdSexo\" value=\"F\">Feminino</label>\n" +
                    "    <br/>\n" +
                    "    Disiciplinas:<br/>\n");
            for (int i = 0; i < base.listarDisciplinas().size(); i++) {
                Disciplina disciplina = base.listarDisciplinas().get(i);
                out.print("    <label><input type=\"checkbox\" name=\"disciplina[]\" value=\"" + disciplina.getCodigo() + "\"");
                out.println(">" + disciplina.getNome() + "</label><br/>\n");
            }
            out.println("    <br/>\n" +
                    "    <br/>\n" +
                    "    <input type=\"submit\" value=\"Cadastrar\">\n" +
                    "</form>\n" +
                    "\n<br/>\n" +
                    "<table border=\"1\">\n" +
                    "    <tr>\n" +
                    "        <th>Aluno</th>\n" +
                    "        <th>Idade</th>\n" +
                    "        <th>Sexo</th>\n" +
                    "        <th>Disciplinas</th>\n" +
                    "    </tr>\n");
            for (Aluno aluno : base.listarAlunos()) {


                out.println("    <tr>\n");
                out.println("        <td>" + aluno.getNome() + "</td>\n");
                out.println("        <td>" + aluno.getIdade() + "</td>\n");
                out.println("        <td>" + aluno.getSexo().getDescricao() + "</td>\n");
                out.println("        <td>" + aluno.listarDisciplina().replace(",","<br/>") + "</td>\n");
                out.println("    </tr>\n");
            }
            out.println("</table>" +
                    "</body>\n" +
                    "</html>");
        } else {
            response.sendRedirect("/logar");
        }
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        byte[] decoded = Base64.getDecoder().decode((String) session.getAttribute("login"));
        String loginValidar = new String(decoded);
        boolean verificacao = false;
        DB base = DB.getInstance();
        for (Usuario usr : base.listarTodosUsuarios()) {
            if (usr.getLogin().equals(loginValidar)) {
                verificacao = true;
                break;
            }
        }
        if (verificacao) {
            String nome = request.getParameter("txtNome");
            int idade = Integer.parseInt(request.getParameter("nrIdade"));
            Sexo sexo;
            if (request.getParameter("rdSexo").equalsIgnoreCase("M")) {
                sexo = Sexo.MASC;
            } else sexo = Sexo.FEM;

            String[] disc =
                    request.getParameterValues("disciplina[]")!=null?request.getParameterValues("disciplina[]"): new String[0];
            Aluno aluno = new Aluno(nome, idade, sexo, construirDisciplinas(disc));
            base.incluirAluno(aluno);
            doGet(request, response);
        } else {
            response.sendRedirect("http://localhost:8080/logar");
        }
    }
    private List<Disciplina> construirDisciplinas(String[] disciplinasArray) {
        DB base = DB.getInstance();
        List<Disciplina> disciplinas = new ArrayList<>();
        for (int i = 0; i < disciplinasArray.length; i++) {
            String teste = disciplinasArray[i];
            Disciplina disciplina = new Disciplina(teste);
            for (Disciplina disc : base.listarDisciplinas()) {
                if (disc.equals(disciplina)) {
                    disciplinas.add(disc);
                }
            }
        }
        return disciplinas;
    }

}
