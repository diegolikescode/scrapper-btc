package br.unisul.aula.pesquisa;

import java.util.Objects;

public class Pergunta {
    private String sgPergunta;
    private String pergunta;

    public Pergunta(String sgPergunta, String pergunta) {
        this.pergunta = pergunta;
        this.sgPergunta=sgPergunta;
    }


    public String getPergunta() {
        return pergunta;
    }

    public String getSgPergunta() {
        return sgPergunta;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pergunta pergunta = (Pergunta) o;
        return Objects.equals(sgPergunta, pergunta.sgPergunta);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sgPergunta);
    }
}
