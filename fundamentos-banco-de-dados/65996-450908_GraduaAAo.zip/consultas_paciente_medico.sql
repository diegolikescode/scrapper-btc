USE `mydb`;

SELECT en_paciente.nome, en_paciente.data_nascimento, en_paciente.estado_civil 
	FROM en_paciente;

SELECT p.nome paciente, m.nome medico, data_nascimento, estado_civil 
	FROM en_paciente AS p, en_medico AS m;

SELECT * FROM en_paciente;

-- Quantos pacientes são do sexo “F” ?
SELECT count(nome) 
	FROM en_paciente 
    WHERE sexo='F';
    
-- Quantos pacientes são do sexo “M” e tem como estado civil “D”?
SELECT count(*) 
	FROM en_paciente 
    WHERE sexo='M' 
		AND estado_civil='D';

-- Quantos pacientes tem o convênio “Santa Paulina”?
SELECT count(*) 
	FROM en_paciente ep, re_paciente_convenio pc, en_convenio ec 
    WHERE 
		ep.seq_paciente=pc.en_paciente_seq_paciente 
        AND pc.en_convenio_seq_convenio=ec.seq_convenio
		AND ec.nomeempresa='Santa Paulina';

-- Quais pacientes consultaram no dia 30-maio?
SELECT ep.nome
	FROM en_paciente ep, en_consultamedica ec
    WHERE 
		ep.seq_paciente=ec.en_paciente_seq_paciente
		AND ec.data='20200530';

-- Quantos pacientes são atendidos pela “Dra Ivone”?
SELECT ep.nome
	FROM en_paciente ep, en_consultamedica ec, en_medico em
    WHERE 
		ep.seq_paciente=ec.en_paciente_seq_paciente
        AND ec.en_medico_seq_medico=em.seq_medico
        AND em.nome='Dra Ivone';
        
-- Quem consulta com o “Dr Eduardo” ou a “Dra Ana Paula”?
SELECT ep.nome
	FROM en_paciente ep, en_consultamedica ec, en_medico em
    WHERE 
		ep.seq_paciente=ec.en_paciente_seq_paciente
        AND ec.en_medico_seq_medico=em.seq_medico
        AND em.nome='Dr Eduardo'
        OR em.nome='Dra Ana Paula';
